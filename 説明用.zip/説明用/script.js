// 画像クリックで拡大/縮小
document.addEventListener('click', function(e) {
  if (e.target.tagName === 'IMG' && e.target.closest('figure')) {
    e.target.classList.toggle('expanded');
  }
});
